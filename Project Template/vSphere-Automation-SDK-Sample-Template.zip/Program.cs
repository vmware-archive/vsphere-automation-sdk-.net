﻿/**
 * *******************************************************
 * Copyright VMware, Inc. 2018.  All Rights Reserved.
 * SPDX-License-Identifier: MIT
 * *******************************************************
 *
 * DISCLAIMER. THIS PROGRAM IS PROVIDED TO YOU "AS IS" WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, WHETHER ORAL OR WRITTEN,
 * EXPRESS OR IMPLIED. THE AUTHOR SPECIFICALLY DISCLAIMS ANY IMPLIED
 * WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY,
 * NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
 */
namespace vmware.samples.$safeprojectname$
{

    using vmware.samples.common;
    using vmware.samples.common.authentication;

    /// <summary>
    /// Description: <TODO>Add description</TODO>
    ///
    /// Author: <TODO>Add author</TODO>
    /// Sample Prerequisites: <TODO>Add sample pre-reqs</TODO>
    /// </summary>
    public class $safeprojectname$ : SamplesBase
    {
    [Option(
        "param1",
        HelpText = "Add description here",
        Required = true)]
    public string Param1 { get; set; }

    [Option(
        "param2",
        HelpText = "Add description here.",
        Required = true)]
    public string Param2 { get; set; }
    public override void Run()
    {
        // Login
        VapiAuthHelper = new VapiAuthenticationHelper();
        SessionStubConfiguration =
            VapiAuthHelper.LoginByUsernameAndPassword(
                Server, UserName, Password);
        /**
         * <TODO> Add sample code</TODO>
         * */
    }

    public override void Cleanup()
    {
        /**
         * <TODO>Add cleanup code</TODO>
         * */
        VapiAuthHelper.Logout();
    }

    public static void Main(string[] args)
    {
        new $safeprojectname$().Execute(args);
    }
}
}
